
const popup=document.getElementById("popup");
document.getElementById("buyBtn").onclick=()=>popup.classList.remove("hidden");

function closePopup(){
popup.classList.add("hidden");
document.getElementById("result").innerText="";
}

document.getElementById("confirmBtn").onclick=async()=>{
const email=document.getElementById("email").value;
if(!email){document.getElementById("result").innerText="Enter email";return;}
try{
const res=await fetch("https://safeguard-license-api.onrender.com/buy",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({email})
});
const data=await res.json();
document.getElementById("result").innerText=data.license?("License: "+data.license):"Error";
}catch(e){
document.getElementById("result").innerText="Backend unavailable";
}
}
